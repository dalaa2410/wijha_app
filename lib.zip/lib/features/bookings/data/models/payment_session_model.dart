import '../../domain/entities/payment_session.dart';

class PaymentSessionModel extends PaymentSession {
  const PaymentSessionModel({
    required super.gateway,
    required super.sessionId,
    required super.amount,
    required super.currency,
    required super.checkoutUrl,
  });

  factory PaymentSessionModel.fromJson(Map<String, dynamic> json) {
    return PaymentSessionModel(
      gateway: json['gateway']?.toString() ?? 'sandbox',
      sessionId: json['session_id']?.toString() ?? '',
      amount: (json['amount'] as num?) ?? 0,
      currency: json['currency']?.toString() ?? 'SYP',
      checkoutUrl: (json['checkout_url'] ?? json['payment_url'] ?? json['url'] ?? '').toString(),
    );
  }
}