import '../../domain/entities/booking.dart';

class BookingModel extends Booking {
  const BookingModel({
    required super.id,
    required super.status,
    required super.expiresAt,
    required super.totalPrice,
    required super.pricePerSeat,
    super.currency,
    required super.seatNumbers,
    super.origin,
    super.destination,
    super.departureTime,
    super.busNumber,
    super.paymentUrl,
  });

  factory BookingModel.fromJson(Map<String, dynamic> json) {
    final tripJson = json['trip'] as Map<String, dynamic>?;
    final rawSeats = json['seats'] as List? ?? [];

    final seatNumbers = rawSeats.map((s) {
      if (s is Map) {
        return (s['seat_number'] ?? s['number'] ?? '').toString();
      }
      return s.toString();
    }).where((s) => s.isNotEmpty).toList();

    final totalPrice = (json['total_price'] as num?) ?? 0;
    final pricePerSeat = (json['price_per_seat'] as num?) ??
        (tripJson?['price'] as num?) ??
        (seatNumbers.isNotEmpty ? totalPrice / seatNumbers.length : 0);

    return BookingModel(
      id: (json['id'] as num).toInt(),
      status: _parseStatus(json['status']?.toString()),
      expiresAt: DateTime.tryParse(json['expires_at']?.toString() ?? '') ??
          DateTime.now().add(const Duration(minutes: 10)),
      totalPrice: totalPrice,
      pricePerSeat: pricePerSeat,
      currency: json['currency']?.toString() ?? 'SYP',
      seatNumbers: seatNumbers,
      origin: (tripJson?['origin'] ?? json['origin'])?.toString(),
      destination: (tripJson?['destination'] ?? json['destination'])?.toString(),
      departureTime: DateTime.tryParse(
        (tripJson?['departure_time'] ?? json['departure_time'])?.toString() ?? '',
      ),
      busNumber: (tripJson?['bus_number'] ?? json['bus_number'] ?? '').toString(),
      paymentUrl: json['payment_url']?.toString(),
    );
  }

  static BookingStatus _parseStatus(String? raw) {
    return switch (raw?.toLowerCase()) {
      'confirmed' || 'paid' => BookingStatus.confirmed,
      'cancelled' || 'canceled' => BookingStatus.cancelled,
      'expired' => BookingStatus.expired,
      _ => BookingStatus.pending,
    };
  }
}