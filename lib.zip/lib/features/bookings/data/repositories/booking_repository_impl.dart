import '../../domain/entities/booking.dart';
import '../../domain/entities/payment_session.dart';
import '../../domain/repositories/booking_repository.dart';
import '../datasources/booking_data_source.dart';

class BookingRepositoryImpl implements BookingRepository {
  final BookingDataSource dataSource;

  BookingRepositoryImpl(this.dataSource);

  @override
  Future<List<Booking>> getMyBookings() => dataSource.getMyBookings();

  @override
  Future<Booking?> getBooking(int bookingId) => dataSource.getBooking(bookingId);

  @override
  Future<PaymentSession> startPayment(int bookingId) =>
      dataSource.startPayment(bookingId);

  @override
  Future<void> markPaid(int bookingId) => dataSource.markPaid(bookingId);

  @override
  Future<void> cancelBooking(int bookingId) =>
      dataSource.cancelBooking(bookingId);
}