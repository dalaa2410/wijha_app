import 'package:equatable/equatable.dart';

enum BookingStatus { pending, confirmed, cancelled, expired }

class Booking extends Equatable {
  final int id;
  final int? tripId;
  final BookingStatus status;
  final DateTime expiresAt;
  final num totalPrice;
  final num pricePerSeat;
  final String currency;
  final List<String> seatNumbers;
  final String? origin;
  final String? destination;
  final DateTime? departureTime;
  final String busNumber;
  final String? paymentUrl;
  final String? ticketCode;
  final String? paymentReference;

  const Booking({
    required this.id,
    this.tripId,
    required this.status,
    required this.expiresAt,
    required this.totalPrice,
    required this.pricePerSeat,
    this.currency = 'SYP',
    required this.seatNumbers,
    this.origin,
    this.destination,
    this.departureTime,
    this.busNumber = '',
    this.paymentUrl,
    this.ticketCode,
    this.paymentReference,
  });

  bool get isHoldExpired =>
      status == BookingStatus.pending && DateTime.now().isAfter(expiresAt);

  BookingStatus get effectiveStatus {
    if (status == BookingStatus.pending && isHoldExpired) {
      return BookingStatus.expired;
    }
    return status;
  }

  bool get isUpcoming =>
      effectiveStatus == BookingStatus.pending ||
      effectiveStatus == BookingStatus.confirmed;

  Booking copyWith({
    int? id,
    int? tripId,
    BookingStatus? status,
    DateTime? expiresAt,
    num? totalPrice,
    num? pricePerSeat,
    String? currency,
    List<String>? seatNumbers,
    String? origin,
    String? destination,
    DateTime? departureTime,
    String? busNumber,
    String? paymentUrl,
    String? ticketCode,
    String? paymentReference,
  }) {
    return Booking(
      id: id ?? this.id,
      tripId: tripId ?? this.tripId,
      status: status ?? this.status,
      expiresAt: expiresAt ?? this.expiresAt,
      totalPrice: totalPrice ?? this.totalPrice,
      pricePerSeat: pricePerSeat ?? this.pricePerSeat,
      currency: currency ?? this.currency,
      seatNumbers: seatNumbers ?? this.seatNumbers,
      origin: origin ?? this.origin,
      destination: destination ?? this.destination,
      departureTime: departureTime ?? this.departureTime,
      busNumber: busNumber ?? this.busNumber,
      paymentUrl: paymentUrl ?? this.paymentUrl,
      ticketCode: ticketCode ?? this.ticketCode,
      paymentReference: paymentReference ?? this.paymentReference,
    );
  }

  @override
  List<Object?> get props => [
        id,
        tripId,
        status,
        expiresAt,
        totalPrice,
        pricePerSeat,
        currency,
        seatNumbers,
        origin,
        destination,
        departureTime,
        busNumber,
        paymentUrl,
        ticketCode,
        paymentReference,
      ];
}