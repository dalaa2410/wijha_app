import '../entities/booking.dart';
import '../entities/payment_session.dart';

abstract class BookingRepository {
  Future<List<Booking>> getMyBookings();
  Future<Booking?> getBooking(int bookingId);
  Future<PaymentSession> startPayment(int bookingId);
  Future<void> markPaid(int bookingId);
  Future<void> cancelBooking(int bookingId);
}