import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:wijha_app/core/network/api_exception.dart';
import 'package:wijha_app/features/bookings/domain/entities/booking.dart';
import 'package:wijha_app/features/bookings/domain/repositories/booking_repository.dart';
import '../../domain/entities/reservation.dart';
import '../../domain/entities/seat.dart';
import '../../domain/entities/seat_map.dart';
import '../../domain/repositories/seat_repository.dart';

enum SeatMapStatus { loading, loaded, failure }

class SeatSelectionState extends Equatable {
  final SeatMapStatus status;
  final SeatMap? seatMap;
  final Set<int> selectedIds;
  final String? message; // رسالة عابرة (SnackBar)
  final String? errorMessage; // سبب فشل التحميل
  final bool isSubmitting; // أثناء إرسال طلب الحجز
  final Reservation? reservation;
  final Booking? activePendingBooking; // الحجز المعلّق القائم إن وُجد

  const SeatSelectionState({
    this.status = SeatMapStatus.loading,
    this.seatMap,
    this.selectedIds = const {},
    this.message,
    this.errorMessage,
    this.isSubmitting = false,
    this.reservation,
    this.activePendingBooking,
  });

  List<Seat> get selectedSeats {
    final map = seatMap;
    if (map == null) return const [];
    return map.seats.where((s) => selectedIds.contains(s.id)).toList();
  }

  int get totalPrice => selectedIds.length * (seatMap?.pricePerSeat ?? 0);

  SeatSelectionState copyWith({
    SeatMapStatus? status,
    SeatMap? seatMap,
    Set<int>? selectedIds,
    String? message,
    String? errorMessage,
    bool? isSubmitting,
    Reservation? reservation,
    Booking? activePendingBooking,
    bool clearMessage = false,
    bool clearReservation = false,
    bool clearPendingBooking = false,
  }) {
    return SeatSelectionState(
      status: status ?? this.status,
      seatMap: seatMap ?? this.seatMap,
      selectedIds: selectedIds ?? this.selectedIds,
      message: clearMessage ? null : (message ?? this.message),
      errorMessage: errorMessage ?? this.errorMessage,
      isSubmitting: isSubmitting ?? this.isSubmitting,
      reservation: clearReservation ? null : (reservation ?? this.reservation),
      activePendingBooking: clearPendingBooking
          ? null
          : (activePendingBooking ?? this.activePendingBooking),
    );
  }

  @override
  List<Object?> get props => [
        status,
        seatMap,
        selectedIds,
        message,
        errorMessage,
        isSubmitting,
        reservation,
        activePendingBooking,
      ];
}

class SeatSelectionCubit extends Cubit<SeatSelectionState> {
  final SeatRepository repository;
  final BookingRepository bookingRepository;
  final int tripId;
  static const int maxSeats = 5;

  SeatSelectionCubit({
    required this.repository,
    required this.bookingRepository,
    required this.tripId,
  }) : super(const SeatSelectionState());

  Future<void> loadSeats({bool keepSelection = true}) async {
    emit(state.copyWith(status: SeatMapStatus.loading));
    try {
      final map = await repository.getSeatMap(tripId);
      if (isClosed) return;

      final selected = keepSelection
          ? state.selectedIds
                .where(
                  (id) => map.seats.any((s) => s.id == id && s.isSelectable),
                )
                .toSet()
          : <int>{};

      emit(
        state.copyWith(
          status: SeatMapStatus.loaded,
          seatMap: map,
          selectedIds: selected,
        ),
      );
      await checkPendingBooking();
    } on ApiException catch (e) {
      if (isClosed) return;
      emit(
        state.copyWith(status: SeatMapStatus.failure, errorMessage: e.message),
      );
    } catch (_) {
      if (isClosed) return;
      emit(
        state.copyWith(
          status: SeatMapStatus.failure,
          errorMessage: 'حدث خطأ غير متوقع',
        ),
      );
    }
  }

  /// التحقق من وجود حجز معلّق + تلوين مقاعد المستخدم (المعلّقة والمؤكدة) باللون الأخضر
  Future<void> checkPendingBooking() async {
    try {
      final bookings = await bookingRepository.getMyBookings();
      if (isClosed) return;

      // 1. جمع أرقام المقاعد الخاصة بالمستخدم في هذه الرحلة (معلّقة أو مؤكدة)
      final mySeatNumbers = <String>{};
      for (final b in bookings) {
        final isThisTrip = b.tripId == null || b.tripId == tripId;
        if (isThisTrip &&
            (b.effectiveStatus == BookingStatus.pending ||
                b.effectiveStatus == BookingStatus.confirmed)) {
          mySeatNumbers.addAll(b.seatNumbers.map((e) => e.trim()));
        }
      }

      // 2. تحديث المقاعد في الخريطة لتصبح isMine = true
      SeatMap? updatedMap = state.seatMap;
      if (updatedMap != null && mySeatNumbers.isNotEmpty) {
        final updatedSeats = updatedMap.seats.map((s) {
          final seatNum = s.number?.trim();
          if (seatNum != null &&
              mySeatNumbers.contains(seatNum) &&
              s.status != SeatStatus.available) {
            return Seat(
              id: s.id,
              number: s.number,
              row: s.row,
              column: s.column,
              type: s.type,
              status: s.status,
              isMine: true,
            );
          }
          return s;
        }).toList();

        updatedMap = SeatMap(
          tripId: updatedMap.tripId,
          busNumber: updatedMap.busNumber,
          totalRows: updatedMap.totalRows,
          totalColumns: updatedMap.totalColumns,
          pricePerSeat: updatedMap.pricePerSeat,
          currency: updatedMap.currency,
          seats: updatedSeats,
          origin: updatedMap.origin,
          destination: updatedMap.destination,
          departureTime: updatedMap.departureTime,
        );
      }

      // 3. البحث عن حجز معلّق لم تنتهِ مهلته لإظهار شريط العودة للدفع
      final pending = bookings.where(
        (b) =>
            b.effectiveStatus == BookingStatus.pending &&
            (b.tripId == null || b.tripId == tripId),
      );

      emit(
        state.copyWith(
          seatMap: updatedMap,
          activePendingBooking: pending.isNotEmpty ? pending.first : null,
          clearPendingBooking: pending.isEmpty,
        ),
      );
    } catch (_) {
      // نتجاهل الخطأ بصمت حتى لا نعيق عرض المقاعد
    }
  }

  Future<void> refresh() => loadSeats(keepSelection: false);

  void toggleSeat(Seat seat) {
    if (!seat.isSelectable) return;

    final selected = {...state.selectedIds};
    if (selected.contains(seat.id)) {
      selected.remove(seat.id);
    } else {
      if (selected.length >= maxSeats) {
        _showMessage('الحد الأقصى $maxSeats مقاعد في الحجز الواحد');
        return;
      }
      selected.add(seat.id);
    }
    emit(state.copyWith(selectedIds: selected));
  }

  Future<void> reserveSelected() async {
    if (state.selectedIds.isEmpty || state.isSubmitting) return;

    emit(state.copyWith(isSubmitting: true));
    try {
      final reservation = await repository.reserveSeats(
        tripId,
        state.selectedIds.toList(),
      );
      if (isClosed) return;
      emit(state.copyWith(isSubmitting: false, reservation: reservation));
      emit(state.copyWith(clearReservation: true));
      await loadSeats(keepSelection: false);
    } on ConflictException catch (e) {
      if (isClosed) return;
      emit(state.copyWith(isSubmitting: false));
      _showMessage(e.message);
      await loadSeats();
    } on ApiException catch (e) {
      if (isClosed) return;
      emit(state.copyWith(isSubmitting: false));
      _showMessage(e.message);
    } catch (_) {
      if (isClosed) return;
      emit(state.copyWith(isSubmitting: false));
      _showMessage('حدث خطأ غير متوقع');
    }
  }

  void _showMessage(String text) {
    emit(state.copyWith(message: text));
    emit(state.copyWith(clearMessage: true));
  }
}